param(
    [string]$ServerUrl = "http://192.168.85.30:3001",
    [string]$InstallPath = "C:\Program Files\PepiUpdaterAgent"
)

$Hostname = $env:COMPUTERNAME

# Utility to log
function Write-AgentLog {
    param([string]$Message)
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logLine = "[$timestamp] $Message"
    Write-Host $logLine
    Add-Content -Path "$InstallPath\agent.log" -Value $logLine
}

Write-AgentLog "Starting PepiAgent Execution Cycle..."

# 1. Gather Telemetry (Live Resource Metrics)
try {
    $cpu = Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average | Select-Object -ExpandProperty Average
    
    $os = Get-CimInstance Win32_OperatingSystem
    $ramTotal = $os.TotalVisibleMemorySize
    $ramFree = $os.FreePhysicalMemory
    $ramUsageRaw = (($ramTotal - $ramFree) / $ramTotal) * 100
    $ramUsage = [math]::Round($ramUsageRaw)

    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    $diskTotal = $disk.Size
    $diskFree = $disk.FreeSpace
    $diskUsageRaw = (($diskTotal - $diskFree) / $diskTotal) * 100
    $diskUsage = [math]::Round($diskUsageRaw)

    $telemetryData = @{
        hostname = $Hostname
        cpu_usage = $cpu
        ram_usage = $ramUsage
        disk_usage = $diskUsage
    }

    $jsonTelemetry = $telemetryData | ConvertTo-Json
    Invoke-RestMethod -Uri "$ServerUrl/api/agent/telemetry" -Method Post -Body $jsonTelemetry -ContentType "application/json" -ErrorAction Stop
    Write-AgentLog "Telemetry sent successfully: CPU $cpu%, RAM $ramUsage%, DISK $diskUsage%"
} catch {
    Write-AgentLog "Failed to send telemetry: $_"
}

# 2. Check for Deployments
try {
    $PendingUrl = "$ServerUrl/api/agent/pending?hostname=$Hostname"
    $tasks = Invoke-RestMethod -Uri $PendingUrl -Method Get -ErrorAction Stop

    foreach ($task in $tasks) {
        Write-AgentLog "Processing deployment task: $($task.deployment_id) - Package: $($task.pkg_name)"
        
        $downloadUrl = "$ServerUrl/api/packages/download/$($task.package_id)"
        $tempZip = "$env:TEMP\update_$($task.package_id).zip"
        
        # Download Package
        Write-AgentLog "Downloading package from $downloadUrl to $tempZip"
        Invoke-WebRequest -Uri $downloadUrl -OutFile $tempZip -ErrorAction Stop

        $TargetFolder = $task.target_path
        
        # SELF-UPDATE LOGIC
        if ($TargetFolder -eq "C:\Program Files\PepiUpdaterAgent" -or $task.pkg_name -match "Agent") {
            Write-AgentLog "Self-Update detected! Applying rename trick..."
            
            # Rename currently running script to avoid file lock
            $currentScriptPath = $MyInvocation.MyCommand.Path
            $oldScriptPath = "$currentScriptPath.old"
            
            if (Test-Path $oldScriptPath) { Remove-Item $oldScriptPath -Force -ErrorAction SilentlyContinue }
            
            Write-AgentLog "Renaming $currentScriptPath to $oldScriptPath"
            Rename-Item -Path $currentScriptPath -NewName (Split-Path $oldScriptPath -Leaf) -Force
            
            Write-AgentLog "Extracting new agent over $TargetFolder"
            Expand-Archive -Path $tempZip -DestinationPath $TargetFolder -Force
            
            Write-AgentLog "Extraction complete. The new agent is in place."
            $statusStr = "success"
            $logStr = "Agent updated successfully."
            
            # Cleanup Zip
            Remove-Item $tempZip -Force -ErrorAction SilentlyContinue
        } else {
            # Standard Deployment Logic
            Write-AgentLog "Extracting package to $TargetFolder"
            if (!(Test-Path $TargetFolder)) { New-Item -ItemType Directory -Force -Path $TargetFolder | Out-Null }
            Expand-Archive -Path $tempZip -DestinationPath $TargetFolder -Force
            
            $statusStr = "success"
            $logStr = "Extracted to $TargetFolder successfully."
            
            # Cleanup
            Remove-Item $tempZip -Force -ErrorAction SilentlyContinue
        }

        # Report Status back to server
        $statusBody = @{
            deployment_id = $task.deployment_id
            device_id = $task.device_id
            status = $statusStr
            progress = 100
            log = $logStr
        } | ConvertTo-Json
        
        Invoke-RestMethod -Uri "$ServerUrl/api/agent/deploy-status" -Method Post -Body $statusBody -ContentType "application/json" -ErrorAction Stop
        Write-AgentLog "Deployment status reported: $statusStr"
        
        # If it was a self-update, exit so task scheduler brings up the new version next cycle
        if ($TargetFolder -eq "C:\Program Files\PepiUpdaterAgent" -or $task.pkg_name -match "Agent") {
            Write-AgentLog "Self-update finished. Exiting current process. New version will run next cycle."
            exit 0
        }
    }
} catch {
    Write-AgentLog "Failed during deployment processing: $_"
}

Write-AgentLog "Cycle Complete."
